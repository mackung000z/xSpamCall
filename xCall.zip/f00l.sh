apt upgrade && apt update
pkg install php

pkg install php
php 1337.php
